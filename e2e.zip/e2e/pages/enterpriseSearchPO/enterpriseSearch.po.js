const { browser, ExpectedConditions } = require("protractor");

function EnterpriseSearchobject()
{


var allSearchitems = element.all(by.xpath('//div[@class="search-wrapper"]/div'));
var searchField = element(by.xpath('//*[@id="searchBox"]'));
var searchBox = element(by.id("searchBox"));
var sugessionItem = element(by.xpath('//*[@id="suggestions"]/li[1]'));
var verifySugession = element.all(by.css("a[class='ng-binding']"));
var invalidSearch = element(by.xpath('//*[@id="spltcontnr"]/section/div/div[1]/div/div/div/div[2]/div[1]/div/span'));
var sugessionItems = element.all(by.xpath('//*[@id="suggestions"]/li'));
var sugessionSize = element.all(by.xpath('//div[@class="search-wrapper"]/div'));

this.get = function(url){

    browser.get(url);
};

this.searchAllitems = function(){

    allSearchitems();
};
this.searchEditbox = fuction()
{
    searchBox();
}

this.enterSearchitem = function(searchitem){

    browser.actions().mouseMove(searchBox).sendKeys(protractor.Key.ENTER).perform().then(function()
    {                 
     element(by.xpath('//*[@id="searchBox"]')).sendKeys("searchitem" + protractor.Key.ENTER).then(function()
   {
     browser.sleep(5000);
   })
 })
    searchField.sendkeys(searchitem);
};

this.verifyEditsearchbox = function()
{
      searchField.getText().then(function(text)
      {
          sugessionItem.getText().then(function(sugessionItemvalue)
          {
            expect(text).toBe(sugessionItemvalue);
          })
                  
      })
};


this.clickSugessionItem = function(){

    sugessionItem.click();
};


this.verifySugession = function(){

    expect((verifySugession).isPresent()).toBe(true);
};

this.invalidErrormsg = function()
{

    expect((invalidSearch).isPresent()).toBe(true);
};

this.addingMultiplesearch = function(sugessionitem)
{
    enterprisesearch.enterSearchitem(sugessionitem); 
    sugessionItems.count().then(function(count)   
     {         
        sugessionItems.getText().then(function(item)
       {        
          for(var i=0;i<count;i++)
             {            
                if(item[i].indexOf(name) != -1)
               {                 
           
                   element(by.xpath('//*[@id="suggestions"]/li['+(i+1)+']')).click().then(function()
                       {
                         browser.sleep(3000);
                        })
            
                 }
              }
         }); 
    });

}

this.verifySugessionsize = function(firstSearchitem)
{

    sugessionSize.getText().then(function(text)
            {
              var valid = "firstSearchitem";
              if(text.indexOf(valid) == -1)
              {
                expect((firstSearchitem).isDisplayed()).toBe(false);
              }
              
            })
            sugessionSize.count().then(function(value)
               {
                      expect(value).toBe(4);               

                })
}            



}

module.exports = new EnterpriseSearchobject();